import { Injectable } from '@angular/core';
import { Note } from '../interfaces/note.interface'

@Injectable({
  providedIn: 'root'
})
export class NoteListService {

  constructor() { }
}
